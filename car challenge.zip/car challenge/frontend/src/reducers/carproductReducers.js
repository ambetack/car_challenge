import { CAR_LIST_REQUEST, CAR_LIST_SUCCESS, CAR_LIST_FAIL, CAR_DETAILS_REQUEST, CAR_DETAILS_SUCCESS, CAR_DETAILS_FAIL, PRODUCT_SAVE_REQUEST, CAR_SAVE_SUCCESS, CAR_SAVE_FAIL, CAR_DELETE_REQUEST, CAR_DELETE_SUCCESS, CAR_DELETE_FAIL } from "../constants/productConstants";

function carListReducer(state = { products: [] }, action) {
    switch (action.type) {
        case car_LIST_REQUEST:
            return { loading: true, products: [] };
        case car_LIST_SUCCESS:
            return { loading: false, products: action.payload };
        case car_LIST_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}

function carDetailsReducer(state = { product: {} }, action) {
    switch (action.type) {
        case car_DETAILS_REQUEST:
            return { loading: true };
        case car_DETAILS_SUCCESS:
            return { loading: false, product: action.payload };
        case car_DETAILS_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}

function carSaveReducer(state = { product: {} }, action) {
    switch (action.type) {
        case car_SAVE_REQUEST:
            return { loading: true };
        case casr_SAVE_SUCCESS:
            return { loading: false, success: true, product: action.payload };
        case car_SAVE_FAIL:
            return { loading: false, error: action.payload };
        default:
            return state;
    }
}

function carDeleteReducer(state = { car: {} }, action) {
    switch (action.type) {
        case PRODUCT_DELETE_REQUEST:
            return { loading: true };
        case car_DELETE_SUCCESS:
            return { loading: false, product: action.payload, success: true };
        case car_DELETE_FAIL:
            return { loading: false, error: action.payload };
        default:
            return state;
    }
}

export { carListReducer, carDetailsReducer, carSaveReducer, carDeleteReducer }