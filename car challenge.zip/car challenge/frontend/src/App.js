import React from 'react';
import './App.css';
import SigninScreen from './screens/SigninScreen';
import RegisterScreen from './screens/RegisterScreen';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';

function App() {
  const userSignIn = useSelector(state => state.userSignIn);
  const { userInfo } = userSignIn;

  const dispatch = useDispatch();
  const handleLogout = () => {
    dispatch(logout());
  }

  const car = useSelector(state => state.cart);
  const { cardetails } = car;
  const removeFromCartHandler = (cardetails) => {
    dispatch(removeFromCar(car));
  }
  return (

    
    
          <div className="header__top">
            <div className="container-fluid">
              <div className="row">
                <div className="col-lg-6 col-md-8 col-sm-6 col-xs-12 ">
                  <p>
                    44 Vo Van Ngan, Thu Duc, HCM - Hotline: 804-377-3580
            </p>
                </div>
                <div className="col-lg-6 col-md-4 col-sm-6 col-xs-12 ">
                  <div className="header__actions">
                    <div className="btn-group ps-dropdown">
                      <a
                        className="dropdown-toggle"
                        href="#"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >{userInfo ? userInfo.isAdmin ? "Admin: " + userInfo.name : "User: " + userInfo.name : 'Login & Regiser'} <i className="fa fa-angle-down" />
                      </a>
                      <ul className="dropdown-menu">
                        <li>
                          {userInfo ? <Link to="/profile">Profile</Link> : <Link to="/signin">Login</Link>}
                        </li>
                        <li>
                          {userInfo ? "" : <Link to="/register">Register</Link>}
                        </li>
                        <li className="menu-item">
                          {userInfo ? <Link onClick={handleLogout} className="button secondary full-width">Logout</Link> : ''}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
         
                              
                  <li className="menu-item menu-item-has-car_make dropdown">
                    <a href="#">Category <i className="fa fa-angle-down" /></a>
                    <ul className="sub-menu">
                     
                     
                        
                        </ul>
                      </li>
                      <li className="menu-item">
                        
                      </li>
                      <li className="menu-item">
                        <Link to="/category/AnVat">Ăn Vặt</Link>
                      </li>
                  
                
                  <li className="menu-item menu-item-has-car list dropdown">
                    <a href="/profile">{userInfo ? userInfo.isAdmin ? "Admin: " + userInfo.name : "User: " + userInfo.name : 'Login & Regiser'} <i className="fa fa-angle-down" /></a>
                    <ul className="sub-menu">
                      <li className="menu-item">
                        <Link to="/favorite/products">Favorite</Link>
                      </li>
                      <li className="menu-item">
                        {userInfo ? <Link to="/profile">Profile</Link> : <Link to="/signin">Login</Link>}
                      </li>
                      <li className="menu-item">
                        {userInfo ? "" : <Link to="/register">Register</Link>}
                      </li>
                      <li className="menu-item">
                        {userInfo && userInfo.isAdmin ? <Link to="/products"><span style={{ color: "red", fontWeight: "bold" }}>Admin:</span> Products Manager</Link> : ""}
                      </li>
                      <li className="menu-item">
                        {userInfo && userInfo.isAdmin ? <Link to="/orders"><span style={{ color: "red", fontWeight: "bold" }}>Admin:</span> Order Manager</Link> : ""}
                      </li>
                      <li className="menu-item">
                        {userInfo ? <Link onClick={handleLogout} className="button secondary full-width">Logout</Link> : ''}
                      </li>
                    </ul>
                  </li>
              
            
             
                <form className="ps-search--header" action="do_action" method="post">
                  <input
                    className="form-control"
                    type="text"
                    placeholder="Search Product…"
                  />
                  <button>
                    <i className="ps-icon-search" />
                  </button>
                </form>
               
                   


      
      <Route path='/signin' component={SigninScreen} />
      <Route path='/register' component={RegisterScreen} />
      
      <div>
        <div className="ps-subscribe">
          <div className="ps-container">
            <div className="row">
              <div className="col-lg-3 col-md-12 col-sm-12 col-xs-12 ">
                <h3>
                  <i className="fa fa-envelope" />
            Sign up to Newsletter
          </h3>
              </div>
              <div className="col-lg-5 col-md-7 col-sm-12 col-xs-12 ">
                <form className="ps-subscribe__form" action="do_action" method="post">
                  <input className="form-control" type="text" placeholder />
                  <button>Sign up now</button>
                </form>
              </div>
              <div className="col-lg-4 col-md-5 col-sm-12 col-xs-12 ">
                <p>
                  ...and receive <span>$20</span> coupon for first shopping.
          </p>
              </div>
            </div>
          </div>
        </div>

                      <p>
                        Email:{" "}
                        <a href="mailto:support@store.com">support@store.com</a>
                      </p>
                      <p>Phone: +84123456789</p>
                  
                  
                </div>
                <div className="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                  <aside className="ps-widget--footer ps-widget--info second">
                    <header>
                      <h3 className="ps-widget__title">Address Office 2</h3>
                    </header>
                    <footer>
                      <p>
                        <strong>44 Vo Van Ngan, Duc Thu, AAA</strong>
                      </p>
                      <p>
                        Email:{" "}
                        <a href="mailto:support@store.com">support@store.com</a>
                      </p>
                      <p>Phone: +84876543210</p>
                    </footer>
                  </aside>
                </div>
                
                  export default App;
