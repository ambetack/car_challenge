import axios from "axios";
import Axios from "axios";
import { CAR_LIST_REQUEST, CAR_LIST_SUCCESS, CAR_LIST_FAIL, CAR_DETAILS_REQUEST, CAR_DETAILS_FAIL, CAR_DETAILS_SUCCESS, CAR_SAVE_REQUEST, CAR_SAVE_SUCCESS, CAR_SAVE_FAIL, CAR_DELETE_REQUEST, CAR_DELETE_SUCCESS, CAR_DELETE_FAIL } from "../constants/carConstants";


const car = (
    category = '',
    searchKeyword = '',
    sortOrder = ''
) => async (dispatch) => {
    try {
        dispatch({ type: CAR_LIST });
        const { data } = await axios.get(
            '/api/products?category=' +
            category +
            '&searchKeyword=' +
            searchKeyword +
            '&sortOrder=' +
            sortOrder
        );
        dispatch({ type: CAR_LIST_SUCCESS, payload: data });
    } catch (error) {
        dispatch({ type: CAR_LIST_FAIL, payload: error.message });
    }
};

const detailscar = (carName) => async (dispatch) => {
    try {
        dispatch({ type: CAR_DETAILS_REQUEST, payload: CARId });
        const { data } = await axios.get('/api/car/' + carId);
        dispatch({ type: car_DETAILS_SUCCESS, payload: data });
    } catch (error) {
        dispatch({ type: PRODUCT_DETAILS_FAIL, payload: error.message });
    }
};

const saveCar = (car) => async (dispatch, getState) => {
    try {
        dispatch({ type: car_SAVE_REQUEST, payload: car });
        const {
            userSignIn: { userInfo },
        } = getState();
        if (!product._id) {
            const { data } = await Axios.post('/api/car', car, {
                headers: {
                   
                },
            });
            dispatch({ type: CAR_SAVE_SUCCESS, payload: data });
        } else {
            const { data } = await Axios.put(
                '/api/car/' + car._id,
                car,
               
                
            );
            dispatch({ type: CAR_SAVE_SUCCESS, payload: data });
        }
    } catch (error) {
        dispatch({ type: CAR_SAVE_FAIL, payload: error.message });
    }
};

const deleteProduct = (carId) => async (dispatch, getState) => {
    try {
        const {
            userSignIn: { userInfo },
        } = getState();
        dispatch({ type: CAR_DELETE_REQUEST, payload: CARId });
        const { data } = await axios.delete('/api/car/' + carId, {
            
        });
        dispatch({ type: CAR_DELETE_SUCCESS, payload: data, success: true });
    } catch (error) {
        dispatch({ type: CAR_DELETE_FAIL, payload: error.message });
    }
};

export { listcar, detailcar, savecar, deletecar };