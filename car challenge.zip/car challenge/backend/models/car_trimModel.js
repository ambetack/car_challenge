import mongoose from 'mongoose';

const car_trimSchema = new mongoose.Schema({
    model_id: { type: String, required: true },
    model_make_id: { type: String, required: true,  },
    model_name: { type: String, required: true },
    model_trim: { type: String, required: true,  },
    model_year:{type:String,required:true, },
    model_body:{type:String,required:true, },
    model_engine_body:{type:String,required:true},
    model_engine_cc:{type:Number,required:true},
    model_engine_cyl:{type:Number,required:true},
    model_engine_type:{type:Number,required:true},
    model_engine_valves_per_cyl:{type:Number,required:true},
    model_engine_power_ps:{type:Number, required:true},
    model_engine_power_rpm:{type:Number,required:true},
    model_engine_torque_nm:{type:Number,required:true},
    make_country:{type:String,required:true},
    
   
    
    




});

const car_trimModel = mongoose.model();

export default car_trimModel;