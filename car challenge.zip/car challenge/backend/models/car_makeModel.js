import mongoose from 'mongoose';
const car_makeSchema =  {
  make_id: { type: String, required: true },
  make_display: { type: String, required: true },
  make_is_common: { type: Number, required: true },
  country: { type: String, required: true },
  make_Year:{type:Number,required:true},
};






  

const car_makeModel = mongoose.model();
export default car_makeModel;