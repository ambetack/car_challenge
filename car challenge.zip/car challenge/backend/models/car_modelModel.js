import mongoose from 'mongoose';


const car_modelSchema = new mongoose.Schema({
  model_name: { type: Number, required: true },
  model_make: { type: String, required: true },
  
  
});

const productModel = mongoose.model();

export default const_modelModel;
