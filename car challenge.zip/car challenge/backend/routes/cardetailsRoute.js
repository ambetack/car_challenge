import express from 'express';
import carDetails from '../models/carDetailsModel';
import { isAuth, isAdmin } from '../util';

const router = express.Router();

// router.get('/', async (req, res) => {
//   const products = await Product.find({});
//   res.send(products);
// });

router.get('/', async (req, res) => {
  const category = req.query.category ? { category: req.query.category } : {};
  const searchKeyword = req.query.searchKeyword
    
    
    
  const sortOrder = req.query.sortOrder
    ? req.query.sortOrder === 'lowest'
      ? { price: 1 }
      : { price: -1 }
    : { _id: -1 };
  const products = await Product.find({ ...category, ...searchKeyword }).sort(
    sortOrder
  );
  res.send(products);
});

router.get('/:id', async (req, res) => {
  const product = await car.findOne({ _id: req.params.id });
  if (product) {
    res.send(car);
  } else {
    res.status(404).send({ message: 'Product Not Found.' });
  }
});

router.put('/:id', async (req, res) => {
  const carDetails = req.params.id;
  const carDetails = await Product.findById(carDetails);
  if (carDetails) {
    car_make = req.body.name;
    car_model = req.body.price;
    car_trim = req.body.image;
    
    const updatedcarDetails = await carDetails.save();
    if (updatedcarDetails) {
      return res
        .status(200)
        .send({ message: 'Product Updated', data: updatedProduct });
    }
  }
  return res.status(500).send({ message: ' Error in Updating Product.' });
});

router.post('/', async (req, res) => {
  const product = new Product({
    car_make: req.body.name,
    car_model: req.body.price,
    car_model: req.body.image,
    
  });
  const newcarDetails = await carDetails.save();
  if (newcarDetails) {
    return res
      .status(201)
      .send({ message: 'cardetails Created', data: newcardetails });
  }
  return res.status(500).send({ message: 'Error is creating product' });
})

router.delete('/:id', async (req, res) => {
  const deletedcardetails = await Product.findById(req.params.id);
  if (deletedcardetails) {
    await deletedcardetails.remove();
    res.send({ message: 'Product Deleted' });
  } else {
    res.send('Error in Deletion.');
  }
});

export default router;
