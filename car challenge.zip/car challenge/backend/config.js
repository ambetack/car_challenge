import dotenv from 'dotenv';

dotenv.config();

export default{
    PORT: process.env.PORT || 5500,
    MONGODB_URL: process.env.MONGODB_URL || 'mongodb://localhost/5500',
    JWT_SECRET: process.env.JWT_SECRET || 'somethingsecret',
    
}